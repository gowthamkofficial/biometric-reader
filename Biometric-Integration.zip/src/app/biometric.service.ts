import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, switchMap } from 'rxjs';
import * as xml2js from 'xml2js';
const url = "http://127.0.0.1:11100"
const morphoURL = 'http://127.0.0.1:11101'


@Injectable({
  providedIn: 'root'
})
export class BiometricService {

  constructor(private http: HttpClient) {
    // super(http);
  }



  getDeviceInformation() { //getDeviceInfo ///rd/info
    return this.http.request('DEVICEINFO', url + "/rd/info", { responseType: "text" }).pipe(
      switchMap(async xml => await this.parseXmlToJson(xml))
    );

  }


  getDeviceStatus(): Observable<any> {
    return this.http.request('RDSERVICE', url, { responseType: "text" }).pipe(
      switchMap(async xml => await this.parseXmlToJson(xml))
    );
  }

  captureFinger(request: any): Observable<any> {
    let params = `<?xml version="1.0"?> <PidOptions ver="${request?.pidOptVer}"> <Opts fCount="${request?.fCount}" fType="${request?.fType}" iCount="${request?.iCount}" pCount="${request?.pCount}" format="${request?.format}"   pidVer="${request?.pidVer}" timeout="${request?.timeout}" posh="${request?.posh}" env="${request?.env}" /> <CustOpts> <Param name="mantrakey" value="undefined" /> </CustOpts> </PidOptions>`
    return this.http.request('CAPTURE', url + "/rd/capture", { body: params, responseType: "text" }).pipe(
      switchMap(async xml => await this.parseXmlToJson(xml))
    );
  }

  async parseXmlToJson(xml: any) {
    return await xml2js
      .parseStringPromise(xml, { explicitArray: false })
      .then(response => response);
  }
}
