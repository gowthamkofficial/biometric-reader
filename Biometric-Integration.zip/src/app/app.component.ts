import { Component, OnInit } from '@angular/core';
import { BiometricService } from './biometric.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'Biometric-Integration';

  device: any

  constructor(private service: BiometricService) { }
  ngOnInit(): void {
    this.service.getDeviceInformation().subscribe({
      next: (res: any) => {
        console.log(res);
        if (res?.DeviceInfo.$) {
          this.device = res?.DeviceInfo.$.mi == 'MFS100' ? 'mantra' : 'morpho'
        } else {
          this.device = null
        }
      },
      error: (err: any) => {
        console.log(err);

        this.device = null
      }
    })

  }





  captureFingerprint(device: 'mantra' | 'morpho') {
    if (this.device) {
      this.service.getDeviceStatus().subscribe((res: any) => {
        console.log(res);

        if (res.RDService.$.status == 'READY') {

        }


        switch (res.RDService.$.status) {
          case 'READY': {
            let config = {
              pidOptVer: '1.0',
              fCount: '1',
              fType: '0',
              iCount: '0',
              pCount: '0',
              format: '0',
              pidVer: '2.0',
              timeout: '10000',
              posh: 'UNKNOWN',
              env: 'P'
            }
            this.service.captureFinger(config).subscribe((result: any) => {
              console.log(result);
            })
          }
            break
          case 'NOTREADY': {
            alert('Your device is not ready . Unplug and connect device again and try...')
          }
            break
        }


      })
    }
  }




}
